package br.com.alura.gerenciador.web;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class RelatorioPeriodo implements Tarefa{

	
	@Override
	public String executa(HttpServletRequest req, HttpServletResponse response) {
		String filtro = req.getParameter("filtro");///aqui é passado o filtro
//		Deverão ser passadas as datas  de inicio e fim do periodo e o fundo
//		Collection<Empresa> empresas = new EmpresaDAO().buscaPorSimilaridade(filtro);
//		req.setAttribute("empresas", empresas);
		return "/WEB-INF/paginas/periodo.jsp";
	}
	
}
