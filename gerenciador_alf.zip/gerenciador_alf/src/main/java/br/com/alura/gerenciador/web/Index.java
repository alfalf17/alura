package br.com.alura.gerenciador.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Index implements Tarefa {

	@Override
	public String executa(HttpServletRequest req, HttpServletResponse resp) {
	
		return "index.jsp";
	}

	
}
